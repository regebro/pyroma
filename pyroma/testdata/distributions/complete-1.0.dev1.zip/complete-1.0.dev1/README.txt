Complete
========

This is a test package for pyroma that is supposed to have a complete
set of metadata and also runnable tests. It should score the maximum possible
on package tests.

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed porttitor, neque at
dignissim condimentum, libero est dictum dolor, sit amet tempor urna diam eget
velit. Suspendisse at odio quam, ut vestibulum ipsum. Nulla facilisi. Nullam
nunc dolor, tempus in vulputate id, fringilla eget metus. Pellentesque nulla
nisl, imperdiet ac vulputate non, commodo tincidunt purus. Aenean sollicitudin
orci eget diam dignissim scelerisque. Donec quis neque nisl, eu adipiscing
velit. Aenean convallis ante sapien. Etiam vitae viverra libero. Nullam ac
ligula erat. Aliquam pellentesque, est eget faucibus pharetra, urna orci rhoncus
nisi, adipiscing elementum libero lectus ut odio. Duis tincidunt mi quam, quis
interdum enim. Nunc sed urna urna, id lacinia turpis. Quisque malesuada, velit
ut tincidunt lacinia, dolor augue varius velit, in ultrices lectus enim et
dolor. Fusce augue eros, aliquet ac dapibus at, tincidunt vitae leo. Lorem ipsum
dolor sit amet, consectetur adipiscing elit. Vivamus sapien neque, fermentum sed
ultrices sit amet, fermentum nec est. Pellentesque imperdiet enim nec velit
posuere id dignissim massa molestie.
