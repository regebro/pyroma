# Various forms of imports, to test dependency detection:
import external1
import external2 as something
import external3.foo
from external4 import somethingelse
from external5.foo import anotherthing
